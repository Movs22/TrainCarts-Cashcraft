package com.bergerkiller.bukkit.tc.signactions;

import com.bergerkiller.bukkit.tc.Permission;
import com.bergerkiller.bukkit.tc.controller.MinecartMember;
import com.bergerkiller.bukkit.tc.events.SignActionEvent;
import com.bergerkiller.bukkit.tc.events.SignChangeActionEvent;
import com.bergerkiller.bukkit.tc.properties.CartProperties;
import com.bergerkiller.bukkit.tc.utils.SignBuildOptions;

public class SignActionRoute extends SignAction {

    @Override
    public boolean match(SignActionEvent info) {
        return info.isType("route");
    }
    
    public static String parseStation(String string) {
		string = string.replaceAll("\\$A", "Ailsbury").replaceAll("\\$C", "Cashvillage").replaceAll("\\$F", "Fernhill").replaceAll("\\$H", "Hemstead").replaceAll("\\$N", "New Arbridge");
		string = string.replaceAll("\\$Rd", "Road").replaceAll("\\$P", "Park");
		string = string.replaceAll("\\$Q", "Quarter").replaceAll("\\$S", "Shopping Centre").replaceAll("\\$R", "Racecourse");
		string = string.replaceAll("\\$S", "South").replaceAll("\\$N", "North").replaceAll("\\$E", "East").replaceAll("\\$W", "West");
		return string;
    }
    int RouteIndex = 0;
    @Override
    public void execute(SignActionEvent info) {

        // Must have rails or nothing will happen (no path finding node)
        if (!info.hasRails()) {
            return;
        }

        // Only activate the sign if it is a cart/train sign, and the appropriate enter event is fired (or redstone-triggered)
        if ( !(info.isTrainSign() && info.isAction(SignActionType.REDSTONE_ON, SignActionType.GROUP_ENTER)) )
        {
            return;
        }
        
        if(info.isAction(SignActionType.GROUP_ENTER)) {
        	String DestStr = info.getLine(1).split("route ")[1];
        	RouteIndex += 1;
        	if(RouteIndex > DestStr.length() - 1) {
        		RouteIndex = 0;
        	}
        	
        }
        // Compute next destination to set for the minecarts and apply it
        for (MinecartMember<?> member : info.getMembers()) {
            String nextDestination = this.getNextDestination(member.getProperties(), info);
            if (nextDestination != null) {
                if (nextDestination.isEmpty()) {
                    member.getProperties().clearDestination();
                } else {
                    member.getProperties().setDestination(parseStation(nextDestination));
                }
            }
        }
    }

    /**
     * Gets the next destination name that should be set for a single Minecart, given an event.
     * If null is returned, then no destination should be set.
     * 
     * @param cart The cart to compute the next destination for
     * @param info Event information
     * @return next destination to set, empty to clear, null to do nothing
     */
    private String getNextDestination(CartProperties cart, SignActionEvent info) {
        // Parse new destination to set. If empty, returns null (set nothing)
    	String[] newDestinations ={info.getLine(2),info.getLine(3)};
        String newDestination = newDestinations[0];
        String DestStr = info.getLine(1).split("route ")[1];
        if(DestStr.charAt(RouteIndex) == '1') {
        	newDestination = newDestinations[0];
        }
        if(DestStr.charAt(RouteIndex) == '2') {
        	newDestination = newDestinations[1];
        }
        if (newDestination.isEmpty()) {
            newDestination = null;
        }

        // If this sign was triggered using a redstone-on signal, set the destination on this sign at all times
        // This ignores route and whether or not the destination on the sign matches that of the train
        if (info.isAction(SignActionType.REDSTONE_ON)) {
            return newDestination;
        }

        // If sign is not powered, this sign does nothing
        if (!info.isPowered()) {
            return null;
        }

        // If the destination name of the sign itself is empty, then this sign
        // always sets the destination to what is on the sign.
        // This acts similar to the property destination sign
        if (info.getLine(2).isEmpty()) {
            return newDestination;
        }

        // If the destination of this sign is not one the train is going for,
        // do not set a new destination just yet.
        if (cart.hasDestination() && !cart.getDestination().equals(info.getLine(2))) {
            return null;
        }

        // Use next destination on route if one is used, otherwise use the fourth line for it
        String nextOnRoute = cart.getNextDestinationOnRoute();
        return nextOnRoute.isEmpty() ? newDestination : nextOnRoute;
    }

    @Override
    public boolean build(SignChangeActionEvent event) {
        SignBuildOptions opt = SignBuildOptions.create()
                .setPermission(Permission.BUILD_ROUTE)
                .setName("train destination")
                .setTraincartsWIKIHelp("TrainCarts/Signs/Destination");

        if (event.isTrainSign()) {
            opt.setDescription("set a train destination.");
        } else if (event.isCartSign()) {
            opt.setDescription("set a cart destination and the next destination to set once it is reached");
        } else if (event.isRCSign()) {
            opt.setDescription("set the destination on a remote train");
        }
        return opt.handle(event.getPlayer());
    }

    @Override
    public String getRailDestinationName(SignActionEvent info) {
        return null;
    }
    
}
