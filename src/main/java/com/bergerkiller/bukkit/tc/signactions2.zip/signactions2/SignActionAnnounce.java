package com.bergerkiller.bukkit.tc.signactions;

import org.bukkit.entity.Player;

import com.bergerkiller.bukkit.tc.Permission;
import com.bergerkiller.bukkit.tc.TrainCarts;
import com.bergerkiller.bukkit.tc.controller.MinecartGroup;
import com.bergerkiller.bukkit.tc.controller.MinecartMember;
import com.bergerkiller.bukkit.tc.events.SignActionEvent;
import com.bergerkiller.bukkit.tc.events.SignChangeActionEvent;
import com.bergerkiller.bukkit.tc.utils.SignBuildOptions;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.chat.ComponentSerializer;

public class SignActionAnnounce extends SignAction {

    public static void sendMessage(SignActionEvent info, MinecartGroup group, String message, String color, Boolean play) {
        for (MinecartMember<?> member : group) {
            sendMessage(info, member, message, color, play);
        }
    }
    public static String convertColor(String name) {
    	if(name.contains("$CHR")) return "#FF0000";
    	if(name.contains("$GAR")) return "#1BF400";
    	if(name.contains("$HS1")) return "#00946F";
    	if(name.contains("$HS2")) return "#00DFFF";
    	if(name.contains("$SVR")) return "#B955FF";
    	if(name.contains("$Blue")) return "#99D9EA";
    	if(name.contains("$Green")) return "#22D74C";
    	if(name.contains("$Orange")) return "#FF7F27";
    	if(name.contains("$Pink")) return "#FFAEC9";
    	if(name.contains("$Red")) return "#ED1C24";
    	if(name.contains("$Yellow")) return "#FCE600";
    	if(name.contains("$NAT")) return "#0075B4";
    	if(name.contains("$FTrams")) return "#BFAF81";
    	return name;
    }
    public static String parseStation(String string) {
		string = string.replaceAll("\\$A", "Ailsbury").replaceAll("\\$C", "Cashvillage").replaceAll("\\$F", "Fernhill").replaceAll("\\$H", "Hemstead").replaceAll("\\$N", "New Arbridge");
		string = string.replaceAll("\\$Rd", "Road").replaceAll("\\$P", "Park");
		string = string.replaceAll("\\$Q", "Quarter").replaceAll("\\$S", "Shopping Centre").replaceAll("\\$R", "Racecourse");
		string = string.replaceAll("\\$S", "South").replaceAll("\\$N", "North").replaceAll("\\$E", "East").replaceAll("\\$W", "West");
		return string;
    }
    public static void sendMessage(SignActionEvent info, MinecartMember<?> member, String message, String color, Boolean play) {
		for(Player player: member.getEntity().getPlayerPassengers()) {
			color = convertColor(color);
        	player.spigot().sendMessage(ChatMessageType.ACTION_BAR, ComponentSerializer.parse("{\"text\":\"" + parseStation(message) + "\", \"color\":\"" + color + "\"}"));
        	if(play) {
        		player.playSound(player.getLocation(), "minecraft:block.note_block.chime", 10, 1);
        		new java.util.Timer().schedule( 
        		        new java.util.TimerTask() {
        		            @Override
        		            public void run() {
        		            	player.playSound(player.getLocation(), "minecraft:block.note_block.chime", 10, (float) 0.85);
        		            }
        		        }, 
        		        300 
        		);
        	}
        }
    }

    public static String getMessage(SignActionEvent info) {
        StringBuilder message = new StringBuilder(16);
        message.append(info.getLine(3));
        for (String line : info.getExtraLinesBelow()) {
            message.append(line);
        }
        return TrainCarts.getMessage(message.toString());
    }
    
    public static String getColor(SignActionEvent info) {
        StringBuilder color = new StringBuilder(16);
        color.append(info.getLine(2).toString().split(" ")[0]);
        return TrainCarts.getMessage(color.toString());
    };
    public static Boolean checkPlay(SignActionEvent info) {
        if(info.getLine(1).contains("S")) {
        	return false;
        }
        return true;
    };

    @Override
    public boolean match(SignActionEvent info) {
        return info.isType("announce");
    }

    @Override
    public void execute(SignActionEvent info) {
        String message = getMessage(info);
        String color = getColor(info);
        Boolean play = checkPlay(info);
        if (info.isTrainSign() && info.isAction(SignActionType.GROUP_ENTER, SignActionType.REDSTONE_ON)) {
            if (!info.hasRailedMember() || !info.isPowered()) return;
            sendMessage(info, info.getGroup(), message, color, play);
        } else if (info.isCartSign() && info.isAction(SignActionType.MEMBER_ENTER, SignActionType.REDSTONE_ON)) {
            if (!info.hasRailedMember() || !info.isPowered()) return;
            sendMessage(info, info.getMember(), message, color, play);
        } else if (info.isRCSign() && info.isAction(SignActionType.REDSTONE_ON)) {
            for (MinecartGroup group : info.getRCTrainGroups()) {
                sendMessage(info, group, message, color, play);
            }
        }
    }
    
    @Override
    public boolean canSupportRC() {
        return true;
    }

    @Override
    public boolean build(SignChangeActionEvent event) {
        if (!event.isType("announce")) {
            return false;
        }

        return SignBuildOptions.create()
                .setPermission(Permission.BUILD_ANNOUNCER)
                .setName("announcer")
                .setDescription(event.isRCSign() ?
                        "remotely send a message to all the players in the train" :
                        "send a message to players in a train")
                .setTraincartsWIKIHelp("TrainCarts/Signs/Announce")
                .handle(event.getPlayer());
    }
}
