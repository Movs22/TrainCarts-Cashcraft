package com.bergerkiller.bukkit.tc.signactions;

public enum SignActionMode {
    TRAIN, CART, RCTRAIN, NONE;
}
