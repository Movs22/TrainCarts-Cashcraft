package com.bergerkiller.bukkit.tc.signactions;

import com.bergerkiller.bukkit.common.Task;
import com.bergerkiller.bukkit.common.utils.ParseUtil;
import com.bergerkiller.bukkit.tc.ArrivalSigns;
import com.bergerkiller.bukkit.tc.Direction;
import com.bergerkiller.bukkit.tc.Permission;
import com.bergerkiller.bukkit.tc.Station;
import com.bergerkiller.bukkit.tc.TrainCarts;
import com.bergerkiller.bukkit.tc.actions.GroupActionWaitStationRouting;
import com.bergerkiller.bukkit.tc.controller.MinecartGroup;
import com.bergerkiller.bukkit.tc.controller.MinecartMember;
import com.bergerkiller.bukkit.tc.events.SignActionEvent;
import com.bergerkiller.bukkit.tc.events.SignChangeActionEvent;
import com.bergerkiller.bukkit.tc.pathfinding.PathPredictEvent;
import com.bergerkiller.bukkit.tc.utils.SignBuildOptions;
import com.bergerkiller.bukkit.tc.utils.TimeDurationFormat;
import com.google.gson.stream.JsonReader;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.chat.ComponentSerializer;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;

public class SignActionStation extends SignAction {

	@Override
	public boolean match(SignActionEvent info) {
		return info.isType("station") && info.getMode() != SignActionMode.NONE;
	}

	public static String convertColor(String name) {
		name = name.split("/")[0];
		if (name.contains("$CHR"))
			return "#FF0000";
		if (name.contains("$GAR"))
			return "#1BF400";
		if (name.contains("$HS1"))
			return "#00946F";
		if (name.contains("$HS2"))
			return "#00DFFF";
		if (name.contains("$SVR"))
			return "#B955FF";
		if (name.contains("$Blue"))
			return "#99D9EA";
		if (name.contains("$Green"))
			return "#22D74C";
		if (name.contains("$Orange"))
			return "#FF7F27";
		if (name.contains("$Pink"))
			return "#FFAEC9";
		if (name.contains("$Red"))
			return "#ED1C24";
		if (name.contains("$Yellow"))
			return "#FCE600";
		if (name.contains("$NAT"))
			return "#0075B4";
		if (name.contains("$FTrams"))
			return "#BFAF81";
		return name;
	}

	public static String parseMetro(String string, String color) {
		String result = "[{\"text\":\"Change here for the \",\"color\":\"" + convertColor(color) + "\"}";
		String a = ", ";
		int b = 0;
		if(string.split(">").length < 1) return null;
		string = string.split(">")[0];
		if(string.equalsIgnoreCase("-")) return null;
		if (string.equalsIgnoreCase("")) return null;
		if (string == "") return null;
		for (int i = 0; i < string.length(); i++) {
			if (string.charAt(i) == 'B') {
				result = result + (", {\"text\":\"Blue\",\"color\":\"" + convertColor("$Blue") + "\"}");
			} else if (string.charAt(i) == 'G') {
				result = result + (", {\"text\":\"Green\",\"color\":\"" + convertColor("$Green") + "\"}");
			} else if (string.charAt(i) == 'O') {
				result = result + (", {\"text\":\"Orange\",\"color\":\"" + convertColor("$Orange") + "\"}");
			} else if (string.charAt(i) == 'P') {
				result = result + (", {\"text\":\"Pink\",\"color\":\"" + convertColor("$Pink") + "\"}");
			} else if (string.charAt(i) == 'R') {
				result = result + (", {\"text\":\"Red\",\"color\":\"" + convertColor("$Red") + "\"}");
			} else if (string.charAt(i) == 'Y') {
				result = result + (", {\"text\":\"Yellow\",\"color\":\"" + convertColor("$Yellow") + "\"}");
			} else {
				if (b == string.length() - 1) {
					if (b == string.length() - 1)
						a = " Line" + (string.length() > 1 ? "s" : "") + ".";
					result = result + (", {\"text\":\"" + a + "\",\"color\":\"" + convertColor(color) + "\"}");
					result = result + "]";
				}
				b += 1;
				continue;
			}
			if (b == string.length() - 1)
				a = " Line" + (string.length() > 1 ? "s" : "") + ".";
			if (b == string.length() - 2)
				a = " and ";
			if (b < string.length() - 2)
				a = ", ";
			result = result + (", {\"text\":\"" + a + "\",\"color\":\"" + convertColor(color) + "\"}");
			if (b == string.length() - 1) {
				result = result + "]";
			}
			b += 1;
		}
		return result;
	}

	public static String parseRail(String string, String color) {
		String result = "[{\"text\":\"Also change here for \",\"color\":\"" + convertColor(color) + "\"}";
		String a = ", ";
		int b = 0;
		if(string.split(">").length < 2) return null;
		string = string.split(">")[1];
		if(string.equalsIgnoreCase("-")) return null;
		if (string.equalsIgnoreCase("")) return null;
		for (int i = 0; i < string.length(); i++) {

			if (string.charAt(i) == '1') {
				result = result + ", {\"text\":\"High Speed 1\",\"color\":\"" + convertColor("$HS1") + "\"}";
			} else if (string.charAt(i) == '2') {
				result = result + (", {\"text\":\"High Speed 2\",\"color\":\"" + convertColor("$HS2") + "\"}");
			} else if (string.charAt(i) == 'S') {
				result = result + (", {\"text\":\"South Valley Railway\",\"color\":\"" + convertColor("$SVR") + "\"}");
			} else if (string.charAt(i) == 'A') {
				result = result
						+ (", {\"text\":\"Greater Arbridge Railway\",\"color\":\"" + convertColor("$GAR") + "\"}");
			} else if (string.charAt(i) == 'N') {
				result = result + (", {\"text\":\"New Arbridge Trams\",\"color\":\"" + convertColor("$NAT") + "\"}");
			} else if (string.charAt(i) == 'F') {
				result = result + (", {\"text\":\"Fernhill Trams\",\"color\":\"" + convertColor("$FTrams") + "\"}");
			} else if (string.charAt(i) == 'C') {
				result = result
						+ (", {\"text\":\"Cashvillage Heritage Rail\",\"color\":\"" + convertColor("$CHR") + "\"}");
			} else {
				if (b == string.length() - 1) {
					if (b == string.length() - 1)
						a = " services.";
					result = result + (", {\"text\":\"" + a + "\",\"color\":\"" + convertColor(color) + "\"}");
					result = result + "]";
				}
				b += 1;
				continue;
			}
			if (b == string.length() - 1)
				a = " services.";
			if (b == string.length() - 2)
				a = " and ";
			if (b < string.length() - 2)
				a = ", ";
			result = result + (", {\"text\":\"" + a + "\",\"color\":\"" + convertColor(color) + "\"}");
			if (b == string.length() - 1) {
				result = result + "]";
			}
			b += 1;
		}
		return result;
	}

	public static String parseStation(String string) {
		if(string == "-") return "";
		string = string.replaceAll("\\$A", "Ailsbury").replaceAll("\\$C", "Cashvillage").replaceAll("\\$F", "Fernhill")
				.replaceAll("\\$H", "Hemstead").replaceAll("\\$N", "New Arbridge");
		string = string.replaceAll("\\$Rd", "Road").replaceAll("\\$P", "Park");
		string = string.replaceAll("\\$Q", "Quarter").replaceAll("\\$S", "Shopping Centre").replaceAll("\\$R",
				"Racecourse");
		string = string.replaceAll("\\$S", "South").replaceAll("\\$N", "North").replaceAll("\\$E", "East")
				.replaceAll("\\$W", "West");
		return string;
	}

	public static void announce(SignActionEvent info, MinecartGroup group, String message, String color, Boolean play,
			Boolean raw) {
		for (MinecartMember<?> member : group) {
			announce(info, member, message, color, play, raw);
		}
	}

	public static void announce(SignActionEvent info, MinecartMember<?> member, String message, String color,
			Boolean play, Boolean raw) {
		if(message == null) return;
		for (Player player : member.getEntity().getPlayerPassengers()) {
			color = convertColor(color);
			if (raw) {
				player.spigot().sendMessage(ChatMessageType.ACTION_BAR, ComponentSerializer.parse(message.toString()));
			} else {
				player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
						ComponentSerializer.parse("{\"text\":\"" + message + "\", \"color\":\"" + color + "\"}"));
			}
			if (play) {
				player.playSound(player.getLocation(), "minecraft:block.note_block.chime", 10, 1);
				new java.util.Timer().schedule(new java.util.TimerTask() {
					@Override
					public void run() {
						player.playSound(player.getLocation(), "minecraft:block.note_block.chime", 10, (float) 0.85);
					}
				}, 300);
			}
		}
	}

	@Override
	public String getStationName(SignActionEvent info) {
		String station;
		station = (parseStation(info.getLine(3)) != "") ? parseStation(info.getLine(3)) : null;
		return station;
	}	

	@Override
	public Boolean isStation() {
		return true;
	}
	
	@Override
	public void execute(SignActionEvent info) {
		if (!info.isAction(SignActionType.REDSTONE_CHANGE, SignActionType.GROUP_ENTER, SignActionType.GROUP_LEAVE)) {
			return;
		}
		if (info.isAction(SignActionType.GROUP_LEAVE)) {
			if (info.getGroup().getActions().isWaitAction()) {
				info.getGroup().getActions().clear();
			}
			if(!info.getExtraLinesBelow()[0].equalsIgnoreCase("") && !info.getExtraLinesBelow()[1].equalsIgnoreCase("")) {
				if(info.getGroup().getProperties().getStations().toArray().length > 0) {
					announce(info, info.getGroup(), "This is a " + info.getLine(2).replaceAll("\\$", "") + " Line service to " + info.getGroup().getProperties().getDestination() + ".", convertColor(info.getLine(2)), true, false);
					ArrivalSigns.trigger(info.getSign(), info.getMember(), info.getExtraLinesBelow()[3].split("#")[info.getGroup().getProperties().getDestIndex() - 1], info.getExtraLinesBelow()[info.getGroup().getProperties().getDestIndex() - 1], true, parseStation(info.getGroup().getProperties().getDestination()));
					Bukkit.getScheduler().runTaskLater(info.getTrainCarts(), () -> {
						announce(info, info.getGroup(), "The next station is " + info.getGroup().getProperties().getNextStation() + ".", convertColor(info.getLine(2)), true, false);
					}, 60L);
				}
			} else {
				new java.util.Timer().schedule(new java.util.TimerTask() {
					@Override
					public void run() {
						ArrivalSigns.timeCalcStartMDest(info.getBlock(), info.getMember(), info.getGroup().getProperties().getDestIndex(), 4, 5);
					}
				}, 20L);
			}
			info.setLevers(false);
			return;
		}
		if (!info.hasRails() || !info.hasGroup() || info.getGroup().isEmpty()) {
			return;
		}
		// Check if not already targeting
		MinecartGroup group = info.getGroup();
		Station station = new Station(info);

		if (info.isAction(SignActionType.GROUP_ENTER)) {
			info.getGroup().getProperties().stop(parseStation(info.getLine(3)));
			announce(info, info.getGroup(), "This station is " + parseStation(info.getLine(3)) + ".", info.getLine(2),
					true, false);
			Bukkit.getScheduler().runTaskLater(info.getTrainCarts(), () -> {
				announce(info, info.getGroup(), "Mind the gap between the train and the platform.",
						convertColor(info.getLine(2)), false, false);
			}, new Long(50));
			if (parseMetro(info.getExtraLinesBelow()[2], info.getLine(2)) != null
					&& parseMetro(info.getExtraLinesBelow()[2], info.getLine(2)) != "[]") {
				Bukkit.getScheduler().runTaskLater(info.getTrainCarts(), () -> {
					announce(info, info.getGroup(),
							parseMetro(info.getExtraLinesBelow()[2], convertColor(info.getLine(2))),
							convertColor(info.getLine(2)), false, true);
				}, new Long(100));
				if (parseRail(info.getExtraLinesBelow()[2], info.getLine(2)) != null
						&& parseMetro(info.getExtraLinesBelow()[2], info.getLine(2)) != "[]") {
					Bukkit.getScheduler().runTaskLater(info.getTrainCarts(), () -> {
						announce(info, info.getGroup(),
								parseRail(info.getExtraLinesBelow()[2], convertColor(info.getLine(2))),
								convertColor(info.getLine(2)), false, true);
					}, new Long(150));
				}
			} else {
				if (parseRail(info.getExtraLinesBelow()[2], info.getLine(2)) != null
						&& parseMetro(info.getExtraLinesBelow()[2], info.getLine(2)) != "[]") {
					Bukkit.getScheduler().runTaskLater(info.getTrainCarts(), () -> {
						announce(info, info.getGroup(),
								parseRail(info.getExtraLinesBelow()[2], convertColor(info.getLine(2))),
								convertColor(info.getLine(2)), false, true);
					}, new Long(100));
				}
			}
		}

		// What do we do?
		if (station.getInstruction() == null) {
			// Clear actions, but only if requested to do so because of a redstone change
			if (info.isAction(SignActionType.REDSTONE_CHANGE)) {
				if (info.getGroup().getActions().isCurrentActionTag(station.getTag())) {
					info.getGroup().getActions().clear();
				}
			}
		} else if (station.getInstruction() == BlockFace.SELF) {
			MinecartMember<?> centerMember = station.getCenterPositionCart();
			// Do not allow redstone changes to center a launching train
			if (info.isAction(SignActionType.REDSTONE_CHANGE)
					&& (centerMember.isMovementControlled() || info.getGroup().isMoving())) {
				return;
			}

			// This erases all previous (station/launch) actions scheduled for the train
			// It allows this station to fully redefine what the train should be doing
			group.getActions().launchReset();

			// Train is waiting on top of the station sign indefinitely, with no
			// end-condition
			if (!station.isAutoRouting() && station.getNextDirection() == Direction.NONE) {
				station.centerTrain();
				station.waitTrain(Long.MAX_VALUE);
				return;
			}

			// If auto-routing, perform auto-routing checks and such
			// All this logic runs one tick delayed, because it is possible a destination
			// sign
			// sits on the same block as this station sign. We want the destination sign
			// logic
			// to execute before the station does routing, otherwise this can go wrong.
			// It also makes it much easier to wait for path finding to finish, or for
			// a (valid) destination to be set on the train.
			if (station.isAutoRouting()) {
				// If there's a delay, wait for that delay and toggle levers, but do
				// not toggle levers back up after the delay times out. This is because
				// the actual station routing logic may want to hold the train for longer.
				if (station.hasDelay()) {
					station.centerTrain();
					station.waitTrainKeepLeversDown(station.getDelay());
				}

				// All the station auto-routing logic occurs in this action, which may spawn
				// new actions such as centering the train or launching it again.
				group.getActions()
						.addAction(new GroupActionWaitStationRouting(station, info.getRailPiece(), station.hasDelay()))
						.addTag(station.getTag());
				return;
			}

			// Order the train to center prior to launching again if not launching into the
			// same
			// direction the train is already moving. Respect any set delay on the sign.
			// Levers are automatically toggled as part of waiting
			BlockFace trainDirection = station.getNextDirectionFace();
			if (station.hasDelay()) {
				station.centerTrain();
				station.waitTrain(station.getDelay());
			} else if (!info.getMember().isDirectionTo(trainDirection)) {
				station.centerTrain();
			}

			// Launch into the direction
			station.launchTo(trainDirection);
		} else {
			// Launch
			group.getActions().launchReset();

			if (station.hasDelay()
					|| (group.head().isMoving() && !info.getMember().isDirectionTo(station.getInstruction()))) {
				// Reversing or has delay, need to center it in the middle first
				station.centerTrain();
			}
			if (station.hasDelay()) {
				station.waitTrain(station.getDelay());
			}
			station.launchTo(station.getInstruction());
		}
	}

	@Override
	public boolean build(SignChangeActionEvent event) {
		return SignBuildOptions.create().setPermission(Permission.BUILD_STATION).setName("station")
				.setDescription("stop, wait and launch trains").setTraincartsWIKIHelp("TrainCarts/Signs/Station")
				.handle(event.getPlayer());
	}

	@Override
	public boolean overrideFacing() {
		return true;
	}

	/*
	 * @Override public boolean isRailSwitcher(SignActionEvent info) { // This
	 * causes too many problems because it expects a train //return
	 * StationConfig.fromSign(info).isAutoRouting();
	 * 
	 * // Check last line of sign for 'route' keyword for (String part :
	 * info.getLine(3).split(" ")) { if (part.equalsIgnoreCase("route")) { return
	 * true; } } return false; }
	 */
}
